import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:watch_manufacturing_inventory_app/app.dart';
import 'package:watch_manufacturing_inventory_app/core/constants/app_strings.dart';
import 'package:watch_manufacturing_inventory_app/core/models/stock_ledger_entry.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(StockLedgerEntryAdapter());
  await Hive.openBox<StockLedgerEntry>(AppStrings.ledgerBoxName);
  runApp(const App());
}
