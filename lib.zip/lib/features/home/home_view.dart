import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:watch_manufacturing_inventory_app/core/constants/app_sizes.dart';
import 'package:watch_manufacturing_inventory_app/core/responsive/responsive_extensions.dart';
import 'package:watch_manufacturing_inventory_app/core/responsive/responsive_layout.dart';
import 'package:watch_manufacturing_inventory_app/core/responsive/screen_preset.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_app_bar.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_bottom_sheet.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_button.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_card.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_dialog.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_dropdown.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_image.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_loader.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_list_view.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_spacing.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_text.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_text_field.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/layout/app_grid.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/layout/responsive_scaffold.dart';
import 'package:watch_manufacturing_inventory_app/features/home/bloc/home_bloc.dart';
import 'package:watch_manufacturing_inventory_app/features/home/bloc/home_event.dart';
import 'package:watch_manufacturing_inventory_app/features/home/bloc/home_state.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  static final Uint8List _transparentPixel = Uint8List.fromList(<int>[
    0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
    0x89, 0x00, 0x00, 0x00, 0x0D, 0x49, 0x44, 0x41, 0x54, 0x78, 0x9C, 0x63, 0x00, 0x01, 0x00, 0x00,
    0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4, 0x00, 0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE,
    0x42, 0x60, 0x82,
  ]);

  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<HomeBloc>(
      create: (_) => HomeBloc(),
      child: BlocBuilder<HomeBloc, HomeState>(
        builder: (context, state) {
          const preset = ScreenPreset.comfortable;

          return ResponsiveScaffold(
            appBar: const AppAppBar(
              title: AppText('BLoC Reusable Template'),
            ),
            screenPreset: preset,
            body: ResponsiveLayout(
              mobile: _buildForm(context, state),
              tablet: _buildForm(context, state),
              desktop: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(flex: 2, child: _buildForm(context, state)),
                  const SizedBox(width: AppSizes.lg),
                  Expanded(
                    child: AppCard(
                      child: Padding(
                        padding: const EdgeInsets.all(AppSizes.lg),
                        child: _buildPlatforms(state.platforms),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildForm(BuildContext context, HomeState state) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppCard(
            child: Padding(
              padding: const EdgeInsets.all(AppSizes.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppText(
                    state.title,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  AppSpacing.vMd,
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: AppImage.memory(
                      _transparentPixel,
                      height: context.responsiveValue(mobile: 140, tablet: 200, desktop: 220),
                      width: double.infinity,
                      fit: BoxFit.cover,
                      color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.15),
                      colorBlendMode: BlendMode.srcATop,
                    ),
                  ),
                  AppSpacing.vMd,
                  AppDropdown<String>(
                    value: state.selectedPlatform,
                    items: state.platforms,
                    itemLabelBuilder: (item) => item,
                    hintText: 'Select platform',
                    onChanged: (value) => context.read<HomeBloc>().add(HomePlatformChanged(value)),
                    decoration: const InputDecoration(labelText: 'Platform'),
                  ),
                  AppSpacing.vMd,
                  AppTextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'Enter title value',
                      labelText: 'Input',
                    ),
                  ),
                  AppSpacing.vMd,
                  if (state.hasError)
                    AppText(
                      state.errorMessage ?? '',
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                  AppSpacing.vMd,
                  AppButton(
                    label: state.isBusy ? 'Please wait...' : 'Submit',
                    isExpanded: true,
                    onPressed: state.isBusy
                        ? null
                        : () => context.read<HomeBloc>().add(HomeInputSubmitted(_controller.text)),
                    icon: state.isBusy ? const AppLoader(size: 16, strokeWidth: 2) : null,
                  ),
                  AppSpacing.vSm,
                  Row(
                    children: [
                      Expanded(
                        child: AppButton(
                          label: 'Open Dialog',
                          onPressed: () {
                            AppDialog.show<void>(
                              context: context,
                              title: const Text('Common AppDialog'),
                              content: Text('Selected platform: ${state.selectedPlatform ?? '-'}'),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.of(context).pop(),
                                  child: const Text('Close'),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                      AppSpacing.hSm,
                      Expanded(
                        child: AppButton(
                          label: 'Open Sheet',
                          onPressed: () {
                            AppBottomSheet.show<void>(
                              context: context,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const AppText('Common AppBottomSheet'),
                                  AppSpacing.vSm,
                                  Text('Current platform: ${state.selectedPlatform ?? '-'}'),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          AppSpacing.vLg,
          AppCard(
            child: Padding(
              padding: const EdgeInsets.all(AppSizes.lg),
              child: _buildPlatformGrid(state.platforms),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlatforms(List<String> platforms) {
    return SizedBox(
      height: 220,
      child: AppListView<String>(
        items: platforms,
        separatorBuilder: (_, index) => const Divider(height: 1),
        itemBuilder: (_, item, index) => ListTile(
          dense: true,
          title: Text(item),
          trailing: const Icon(Icons.check_circle_outline),
        ),
      ),
    );
  }

  Widget _buildPlatformGrid(List<String> platforms) {
    return SizedBox(
      height: 240,
      child: AppGrid<String>(
        screenPreset: ScreenPreset.comfortable,
        items: platforms,
        mobileCrossAxisCount: 2,
        tabletCrossAxisCount: 3,
        desktopCrossAxisCount: 3,
        childAspectRatio: 2.7,
        itemBuilder: (context, item, index) => AppCard(
          child: Center(
            child: Text(
              item,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
        ),
      ),
    );
  }
}
