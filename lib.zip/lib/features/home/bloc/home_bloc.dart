import 'dart:async';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:watch_manufacturing_inventory_app/core/services/snackbar_service.dart';
import 'package:watch_manufacturing_inventory_app/features/home/bloc/home_event.dart';
import 'package:watch_manufacturing_inventory_app/features/home/bloc/home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeBloc() : super(HomeState.initial()) {
    on<HomeInputSubmitted>(_onInputSubmitted);
    on<HomePlatformChanged>(_onPlatformChanged);
  }

  Future<void> _onInputSubmitted(
    HomeInputSubmitted event,
    Emitter<HomeState> emit,
  ) async {
    final value = event.value.trim();
    if (value.isEmpty) {
      emit(state.copyWith(status: HomeStatus.error, errorMessage: 'Please enter text before submit.'));
      return;
    }

    emit(state.copyWith(status: HomeStatus.loading, clearErrorMessage: true));
    await Future<void>.delayed(const Duration(milliseconds: 900));
    emit(state.copyWith(title: value, status: HomeStatus.success));

    SnackBarService.instance.show(message: 'Updated successfully');
    emit(state.copyWith(status: HomeStatus.idle));
  }

  void _onPlatformChanged(HomePlatformChanged event, Emitter<HomeState> emit) {
    emit(state.copyWith(selectedPlatform: event.platform));
  }
}
