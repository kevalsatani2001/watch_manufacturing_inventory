import 'package:equatable/equatable.dart';

sealed class HomeEvent extends Equatable {
  const HomeEvent();

  @override
  List<Object?> get props => <Object?>[];
}

final class HomeInputSubmitted extends HomeEvent {
  const HomeInputSubmitted(this.value);

  final String value;

  @override
  List<Object?> get props => <Object?>[value];
}

final class HomePlatformChanged extends HomeEvent {
  const HomePlatformChanged(this.platform);

  final String? platform;

  @override
  List<Object?> get props => <Object?>[platform];
}
