import 'package:equatable/equatable.dart';

enum HomeStatus { idle, loading, success, error }

class HomeState extends Equatable {
  const HomeState({
    required this.title,
    required this.platforms,
    required this.selectedPlatform,
    required this.status,
    required this.errorMessage,
  });

  factory HomeState.initial() {
    const platforms = <String>['Android', 'iOS', 'Web', 'Windows', 'macOS', 'Linux'];
    return const HomeState(
      title: 'Reusable BLoC Structure',
      platforms: platforms,
      selectedPlatform: 'Android',
      status: HomeStatus.idle,
      errorMessage: null,
    );
  }

  final String title;
  final List<String> platforms;
  final String? selectedPlatform;
  final HomeStatus status;
  final String? errorMessage;

  bool get isBusy => status == HomeStatus.loading;
  bool get hasError => status == HomeStatus.error;

  HomeState copyWith({
    String? title,
    List<String>? platforms,
    String? selectedPlatform,
    HomeStatus? status,
    String? errorMessage,
    bool clearErrorMessage = false,
  }) {
    return HomeState(
      title: title ?? this.title,
      platforms: platforms ?? this.platforms,
      selectedPlatform: selectedPlatform ?? this.selectedPlatform,
      status: status ?? this.status,
      errorMessage: clearErrorMessage ? null : (errorMessage ?? this.errorMessage),
    );
  }

  @override
  List<Object?> get props => <Object?>[title, platforms, selectedPlatform, status, errorMessage];
}
