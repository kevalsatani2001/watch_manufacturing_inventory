import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:watch_manufacturing_inventory_app/core/constants/app_colors.dart';
import 'package:watch_manufacturing_inventory_app/core/constants/app_sizes.dart';
import 'package:watch_manufacturing_inventory_app/core/constants/app_strings.dart';
import 'package:watch_manufacturing_inventory_app/core/responsive/responsive_layout.dart';
import 'package:watch_manufacturing_inventory_app/core/responsive/screen_preset.dart';
import 'package:watch_manufacturing_inventory_app/core/router/app_router.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_app_bar.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_card.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_spacing.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/common/app_text.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/layout/app_grid.dart';
import 'package:watch_manufacturing_inventory_app/core/widgets/layout/responsive_scaffold.dart';

class DashboardView extends StatelessWidget {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <_DashItem>[
      const _DashItem(
        icon: Icons.inventory_2_outlined,
        title: AppStrings.inventoryTitle,
        subtitle: AppStrings.stockIn,
        route: AppRouter.inventory,
      ),
      const _DashItem(
        icon: Icons.precision_manufacturing_outlined,
        title: AppStrings.productionTitle,
        subtitle: AppStrings.productionSubtitle,
        route: AppRouter.production,
      ),
      const _DashItem(
        icon: Icons.receipt_long_outlined,
        title: AppStrings.salesTitle,
        subtitle: AppStrings.createOrder,
        route: AppRouter.sales,
      ),
      const _DashItem(
        icon: Icons.assignment_return_outlined,
        title: AppStrings.returnsTitle,
        subtitle: AppStrings.dismantleWatch,
        route: AppRouter.returns,
      ),
    ];

    return ResponsiveScaffold(
      appBar: const AppAppBar(
        backgroundColor: AppColors.obsidianMidnight,
        title: AppText(AppStrings.dashboardTitle),
      ),
      backgroundColor: AppColors.obsidianMidnight,
      body: ResponsiveLayout(
        mobile: _buildMobile(context, items),
        tablet: _buildTablet(context, items),
        desktop: _buildDesktop(context, items),
      ),
    );
  }

  Widget _buildMobile(BuildContext context, List<_DashItem> items) {
    return AnimationLimiter(
      child: ListView(
        children: AnimationConfiguration.toStaggeredList(
          duration: const Duration(milliseconds: 350),
          childAnimationBuilder: (widget) => SlideAnimation(
            verticalOffset: AppSizes.xl,
            child: FadeInAnimation(child: widget),
          ),
          children: <Widget>[
            _headerCard(context),
            ...items.map((i) => _navTile(context, item: i)),
          ],
        ),
      ),
    );
  }

  Widget _buildTablet(BuildContext context, List<_DashItem> items) {
    return ListView(
      children: <Widget>[
        _headerCard(context),
        AppSpacing.vMd,
        AppGrid<_DashItem>(
          items: items,
          screenPreset: ScreenPreset.comfortable,
          mobileCrossAxisCount: 1,
          tabletCrossAxisCount: 2,
          desktopCrossAxisCount: 2,
          childAspectRatio: 1.55,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, item, index) => _navCard(context, item: item),
        ),
      ],
    );
  }

  Widget _buildDesktop(BuildContext context, List<_DashItem> items) {
    return ListView(
      children: <Widget>[
        _headerCard(context),
        AppSpacing.vMd,
        AppGrid<_DashItem>(
          items: items,
          screenPreset: ScreenPreset.spacious,
          mobileCrossAxisCount: 1,
          tabletCrossAxisCount: 2,
          desktopCrossAxisCount: 2,
          childAspectRatio: 1.75,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, item, index) => _navCard(context, item: item),
        ),
      ],
    );
  }

  Widget _headerCard(BuildContext context) {
    return _glassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            AppStrings.appTitle,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w800,
                ),
          ),
          AppSpacing.vXs,
          Text(
            'Luxury Manufacturing • Offline-first Ledger',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _navCard(
    BuildContext context, {
    required _DashItem item,
  }) {
    return _glassCard(
      child: InkWell(
        borderRadius: BorderRadius.circular(AppSizes.lg),
        onTap: () => Navigator.of(context).pushNamed(item.route),
        child: Padding(
          padding: const EdgeInsets.all(AppSizes.sm),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Container(
                    height: 48,
                    width: 48,
                    decoration: BoxDecoration(
                      color: AppColors.cardGlass,
                      borderRadius: BorderRadius.circular(AppSizes.md),
                      border: Border.all(color: AppColors.borderGlass),
                    ),
                    child: Icon(item.icon, color: AppColors.goldenAmber),
                  ),
                  const Spacer(),
                  const Icon(Icons.open_in_new, color: AppColors.textSecondary, size: 18),
                ],
              ),
              AppSpacing.vMd,
              Text(
                item.title,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w800,
                    ),
              ),
              AppSpacing.vXs,
              Text(
                item.subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.textSecondary),
              ),
              const Spacer(),
              Row(
                children: <Widget>[
                  Text(
                    'Open',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppColors.goldenAmber,
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                  const SizedBox(width: AppSizes.xs),
                  const Icon(Icons.arrow_forward, color: AppColors.goldenAmber, size: 18),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navTile(
    BuildContext context, {
    required _DashItem item,
  }) {
    return _glassCard(
      child: InkWell(
        borderRadius: BorderRadius.circular(AppSizes.lg),
        onTap: () => Navigator.of(context).pushNamed(item.route),
        child: Padding(
          padding: const EdgeInsets.all(AppSizes.sm),
          child: Row(
            children: <Widget>[
              Container(
                height: 44,
                width: 44,
                decoration: BoxDecoration(
                  color: AppColors.cardGlass,
                  borderRadius: BorderRadius.circular(AppSizes.md),
                  border: Border.all(color: AppColors.borderGlass),
                ),
                child: Icon(item.icon, color: AppColors.goldenAmber),
              ),
              AppSpacing.hMd,
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      item.title,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    AppSpacing.vXs,
                    Text(
                      item.subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: AppColors.textSecondary),
            ],
          ),
        ),
      ),
    );
  }

  Widget _glassCard({required Widget child}) {
    return AppCard(
      color: AppColors.cardGlass,
      shadowColor: AppColors.obsidianMidnight,
      elevation: AppSizes.xs,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppSizes.lg),
        side: const BorderSide(color: AppColors.borderGlass),
      ),
      child: Padding(
        padding: const EdgeInsets.all(AppSizes.lg),
        child: child,
      ),
    );
  }
}

class _DashItem {
  const _DashItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.route,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String route;
}

