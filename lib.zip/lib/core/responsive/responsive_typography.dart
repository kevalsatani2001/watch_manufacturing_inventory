import 'package:flutter/widgets.dart';
import 'package:watch_manufacturing_inventory_app/core/responsive/responsive_layout.dart';

class ResponsiveTypography {
  const ResponsiveTypography._();

  static TextScaler scalerForWidth(double width) {
    final type = ResponsiveLayout.deviceType(width);
    switch (type) {
      case DeviceType.mobile:
        return const TextScaler.linear(0.95);
      case DeviceType.tablet:
        return const TextScaler.linear(1.0);
      case DeviceType.desktop:
        return const TextScaler.linear(1.05);
    }
  }
}
