import 'package:hive/hive.dart';
import 'package:watch_manufacturing_inventory_app/core/constants/app_strings.dart';
import 'package:watch_manufacturing_inventory_app/core/enums/inventory_enums.dart';
import 'package:watch_manufacturing_inventory_app/core/models/stock_ledger_entry.dart';

class StockLedgerHiveService {
  StockLedgerHiveService._();

  static final StockLedgerHiveService instance = StockLedgerHiveService._();

  static const String inTransaction = 'IN';
  static const String outTransaction = 'OUT';

  Box<StockLedgerEntry> get _ledgerBox => Hive.box<StockLedgerEntry>(AppStrings.ledgerBoxName);

  Future<void> addEntry({
    required String itemName,
    required String transactionType,
    required int quantity,
    required String reason,
  }) async {
    final itemType = ItemType.tryFromLegacyName(itemName);
    final txType = LedgerTxType.tryFromLegacy(transactionType);
    await _ledgerBox.add(
      StockLedgerEntry(
        itemName: itemName,
        transactionType: transactionType,
        quantity: quantity,
        createdAt: DateTime.now(),
        reason: reason,
        itemTypeCode: itemType?.code,
        txTypeCode: txType?.code,
      ),
    );
  }

  String lowStockMessage({required int requiredQty, required int availableQty}) {
    return AppStrings.lowStockWithNumbers
        .replaceAll('{required}', requiredQty.toString())
        .replaceAll('{available}', availableQty.toString());
  }

  int currentStockOf(String itemName) {
    final stock = calculateCurrentStock();
    return stock[itemName] ?? 0;
  }

  List<String> supportedItems() {
    return <String>[
      AppStrings.dial,
      AppStrings.watchCase,
      AppStrings.machine,
      AppStrings.watch,
    ];
  }

  Future<void> stockIn({
    required String itemName,
    required int quantity,
    required String reason,
  }) async {
    if (quantity <= 0) {
      throw ArgumentError.value(quantity, 'quantity');
    }
    await addEntry(
      itemName: itemName,
      transactionType: inTransaction,
      quantity: quantity,
      reason: reason,
    );
  }

  Future<void> stockOut({
    required String itemName,
    required int quantity,
    required String reason,
  }) async {
    if (quantity <= 0) {
      throw ArgumentError.value(quantity, 'quantity');
    }
    final available = currentStockOf(itemName);
    if (available < quantity) {
      throw StateError(lowStockMessage(requiredQty: quantity, availableQty: available));
    }
    await addEntry(
      itemName: itemName,
      transactionType: outTransaction,
      quantity: quantity,
      reason: reason,
    );
  }

  int maxAssemblable() {
    final stock = calculateCurrentStock();
    final dials = stock[AppStrings.dial] ?? 0;
    final cases = stock[AppStrings.watchCase] ?? 0;
    final machines = stock[AppStrings.machine] ?? 0;
    final min1 = dials < cases ? dials : cases;
    return min1 < machines ? min1 : machines;
  }

  Future<void> seedInitialStockIfEmpty() async {
    if (_ledgerBox.isNotEmpty) {
      return;
    }

    await addEntry(
      itemName: AppStrings.dial,
      transactionType: inTransaction,
      quantity: 20,
      reason: AppStrings.reasonInitialStock,
    );
    await addEntry(
      itemName: AppStrings.watchCase,
      transactionType: inTransaction,
      quantity: 20,
      reason: AppStrings.reasonInitialStock,
    );
    await addEntry(
      itemName: AppStrings.machine,
      transactionType: inTransaction,
      quantity: 20,
      reason: AppStrings.reasonInitialStock,
    );
  }

  Map<String, int> calculateCurrentStock() {
    final stock = <String, int>{
      AppStrings.dial: 0,
      AppStrings.watchCase: 0,
      AppStrings.machine: 0,
      AppStrings.watch: 0,
    };

    for (final entry in _ledgerBox.values) {
      final multiplier = entry.transactionType == inTransaction ? 1 : -1;
      stock.update(
        entry.itemName,
        (value) => value + (entry.quantity * multiplier),
        ifAbsent: () => entry.quantity * multiplier,
      );
    }

    return stock;
  }

  bool canAssemble({required int quantity}) {
    final stock = calculateCurrentStock();
    return (stock[AppStrings.dial] ?? 0) >= quantity &&
        (stock[AppStrings.watchCase] ?? 0) >= quantity &&
        (stock[AppStrings.machine] ?? 0) >= quantity;
  }

  Future<void> assembleWatches({required int quantity}) async {
    if (!canAssemble(quantity: quantity)) {
      throw StateError(AppStrings.lowStockMessage);
    }

    await addEntry(
      itemName: AppStrings.dial,
      transactionType: outTransaction,
      quantity: quantity,
      reason: AppStrings.reasonAssemblyComponentsOut,
    );
    await addEntry(
      itemName: AppStrings.watchCase,
      transactionType: outTransaction,
      quantity: quantity,
      reason: AppStrings.reasonAssemblyComponentsOut,
    );
    await addEntry(
      itemName: AppStrings.machine,
      transactionType: outTransaction,
      quantity: quantity,
      reason: AppStrings.reasonAssemblyComponentsOut,
    );
    await addEntry(
      itemName: AppStrings.watch,
      transactionType: inTransaction,
      quantity: quantity,
      reason: AppStrings.reasonProductionOutput,
    );
  }

  Future<int> assembleWatchesPartialAllowed({required int requestedQuantity}) async {
    final allowed = maxAssemblable();
    if (allowed <= 0) {
      throw StateError(AppStrings.lowStockMessage);
    }
    final actual = requestedQuantity <= allowed ? requestedQuantity : allowed;
    await assembleWatches(quantity: actual);
    return actual;
  }

  Future<void> createSalesOrder({required int quantity}) async {
    await stockOut(itemName: AppStrings.watch, quantity: quantity, reason: AppStrings.reasonSale);
  }

  Future<void> returnFinishedWatch({required int quantity}) async {
    await stockIn(itemName: AppStrings.watch, quantity: quantity, reason: AppStrings.reasonReturn);
  }

  Future<void> dismantleReturnedWatch({required int quantity}) async {
    final availableWatches = currentStockOf(AppStrings.watch);
    if (availableWatches < quantity) {
      throw StateError(AppStrings.insufficientFinishedWatch);
    }
    await stockOut(itemName: AppStrings.watch, quantity: quantity, reason: AppStrings.reasonDismantle);
    await stockIn(itemName: AppStrings.dial, quantity: quantity, reason: AppStrings.reasonDismantle);
    await stockIn(itemName: AppStrings.watchCase, quantity: quantity, reason: AppStrings.reasonDismantle);
    await stockIn(itemName: AppStrings.machine, quantity: quantity, reason: AppStrings.reasonDismantle);
  }

  List<StockLedgerEntry> recentEntries({int limit = 15}) {
    final values = _ledgerBox.values.toList().reversed.toList();
    if (values.length <= limit) {
      return values;
    }
    return values.take(limit).toList();
  }
}
