import 'package:flutter/material.dart';

class AppColors {
  const AppColors._();

  static const Color obsidianMidnight = Color(0xFF0F172A);
  static const Color goldenAmber = Color(0xFFF59E0B);
  static const Color cardGlass = Color(0x1AFFFFFF);
  static const Color borderGlass = Color(0x33FFFFFF);
  static const Color textPrimary = Color(0xFFE5E7EB);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color surfaceElevated = Color(0xFF111C33);
  static const Color success = Color(0xFF22C55E);
  static const Color danger = Color(0xFFEF4444);
}
